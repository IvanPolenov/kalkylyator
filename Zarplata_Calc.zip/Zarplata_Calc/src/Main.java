public class Main {
    public static void main(String[] args) {
        Gui_main app = new Gui_main();
        app.setVisible(true);
    }
}